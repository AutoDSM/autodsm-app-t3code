# Provider Packs

## v1 Position

Provider packs are future-facing rendering helpers. v1 should not become a top-20-library adapter project.

## v1 Supported Sources

- Modern Starter
- shadcn/ui fork

## v1.1+ Hooks

Additional library providers such as MUI, Chakra, Mantine, and Radix-specific packs may be added after the core workspace loop ships.
